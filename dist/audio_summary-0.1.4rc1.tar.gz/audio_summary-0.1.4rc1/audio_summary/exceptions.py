class OpenaiApiKeyNotFound(Exception):
    pass

class GeminiApiKeyNotFound(Exception):
    pass

class GeminiSummarizedFailed(Exception):
    pass