ORIGINAL = "Please use original language of the transcription. "

ZH_TW = "Please response in traditional chinese (繁體中文 台灣)"

EN = "Please response in english."