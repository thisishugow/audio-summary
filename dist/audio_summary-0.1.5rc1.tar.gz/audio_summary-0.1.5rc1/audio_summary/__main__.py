import asyncio
from audio_summary import app


if __name__ == "__main__":
    asyncio.run(app.run())