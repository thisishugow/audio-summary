RESPONSE_IN_MARKDOWN = "Response the result in markdown."
