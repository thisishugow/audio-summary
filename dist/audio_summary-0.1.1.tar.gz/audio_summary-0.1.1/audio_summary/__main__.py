from audio_summary import app


if __name__ == "__main__":
    app.make_transcription()